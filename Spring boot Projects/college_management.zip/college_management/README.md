# College Management System (Spring Boot REST API)

A Spring Boot-based RESTful API project that manages student records in a college system. This app showcases layered architecture, custom exception handling, validation, and unit testing using JUnit & Mockito.

## Technologies Used

- Java 17  
- Spring Boot 3.1.4  
- Spring Data JPA  
- MySQL  
- Maven  
- Lombok  
- Springdoc OpenAPI (Swagger UI)  
- SLF4J with Logback  
- JUnit 5 + Mockito  

---

## Features

- Add a new student  
- View all students  
- Get student by ID  
- Search students by name  
- Update student details  
- Delete student  

---
## Project Structure

## Entity: `Student`
- Fields: `id`, `name`, `age`, `address`  
- Annotated with JPA and validation constraints  
- Table: `student`

## Repository: `StudentRepository`
- Extends `JpaRepository<Student, Long>`  
- Custom method: `findByNameContainingIgnoreCase(String name)`

##  Service: `StudentService`
- Manages business logic and validation  
- Delegates data access to repository

##  Controller: `StudentController`
- Exposes REST endpoints:
  - `POST /students`
  - `GET /students`
  - `GET /students/{id}`
  - `GET /students/search?name={name}`
  - `PUT /students/{id}`
  - `DELETE /students/{id}`

## Spring Boot Validation

- Uses `@Valid` in controller  
- Entity uses:
  - `@NotNull`
  - `@Size`
  - `@Min` / `@Max`  
- Handles `MethodArgumentNotValidException` in global exception handler

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-validation</artifactId>
</dependency>
```

## Unit Testing: JUnit 5 & Mockito

- It is primarily used to write and run unit tests, which test individual components or methods of your code in isolation.

- JUnit helps developers verify that their code behaves as expected by providing annotations (like @Test), assertions (like assertEquals, assertTrue), and test runners.

- Running JUnit tests helps catch bugs early during development and ensures code quality and correctness.

- Mockito is a mocking framework used with JUnit to create fake/mock/dummy objects for dependencies, allowing you to isolate the code under test without relying on real external resources.

**How they work together:**

- @SpringBootTest: loads Spring context

- @MockBean: creates fake repositories

- @InjectMocks: injects mocks into services

- when(...).thenReturn(...): sets mock behavior

- assertEquals(...): verifies expected results

## Sample Test: StudentService

```java
@MockBean
private StudentRepository repo;

@Test
public void getStudentByIdTest() {
    Long id = 1L;
    Student student = new Student(id, "raju", 12, "hyd");

    when(repo.findById(id)).thenReturn(Optional.of(student));
    Student fetched = service.getStudentById(id);

    assertEquals("raju", fetched.getName());
}
```
##  Test Methods

- getStudentsTest()
- getStudentByIdTest()
- getStudentByNameTest()
- createStudentTest()
- updateStudentTest()
- deleteStudentTest()

## Setup Instructions

1. **MySQL DB Setup**
   - Create DB `banking_app`
   - Update `application.properties`:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/banking_app
spring.datasource.username=yourUsername
spring.datasource.password=yourPassword
```
2. **Run the App**  
   - Port: `8090`  
   - Swagger UI: `http://localhost:8090/BankingApplication/swagger-ui.html`
   
## Caching

- Caching is a mechanism to store frequently accessed data (like database results, API responses, etc.) in memory (or other fast-access stores).
A cache is a temporary storage that sits between your app and the database or service (or another service).
It saves recent or frequently used data so that when the same data is needed again, it can be returned faster without asking the database again.

1. **In-Memory Caching **
	- Cache is stored locally inside the application’s JVM memory.  Works well for single-instance or monolithic applications. Fast access and easy to use.
2. **Distributed Caching**
	- Cache is stored outside the application in a distributed system (like a separate server or cluster), accessible by multiple instances of the app.
		Examples:
		Redis
		
** Enable Caching **

- Step 1: Enable Caching:  Add `@EnableCaching` to the main application class to activate caching throughout your Spring Boot project.

```java
@SpringBootApplication
@EnableCaching
public class CollegeManagementApplication {
    public static void main(String[] args) {
        SpringApplication.run(CollegeManagementApplication.class, args);
    }
}
```

- Step 2 :  Use Caching Annotations in Your Service Layer
 
  `@Cacheable` : Used on methods to cache the result. If the method is called again with the same arguments, the cached result is returned instead of executing the method again.

```java
@Cacheable(value = "studentById", key = "#id")
public Student getStudentById(Long id) {
    // Called only if 'studentById' with this ID is not in cache
    return studentRepository.findById(id)
        .orElseThrow(() -> new StudentNotFoundException("Student not found"));
}

```

- step 3 : `@CachePut` : Always executes the method and updates the cache with the returned value. Useful for update operations where the cache must be refreshed.

```
@CachePut(value = "studentById", key = "#id")
@CacheEvict(value = { "students", "studentByName" }, allEntries = true)
public Student updateStudent(Long id, Student updatedStudent) {
    Student student = studentRepository.findById(id)
        .orElseThrow(() -> new StudentNotFoundException("Student not found"));

    student.setName(updatedStudent.getName());
    student.setAge(updatedStudent.getAge());
    student.setAddress(updatedStudent.getAddress());

    return studentRepository.save(student);
}
```
Ensures the updated student is stored in cache for future reads.

- step 4 : `@CacheEvict` : Used to remove entries from the cache. Ideal for delete operations or after updates to maintain consistency.

```
@CacheEvict(value = { "studentById", "students", "studentByName" }, allEntries = true)
public String deleteStudent(Long id) {
    Student student = studentRepository.findById(id)
        .orElseThrow(() -> new StudentNotFoundException("Student not found"));

    studentRepository.delete(student);
    return "Student with ID " + id + " deleted successfully.";
}

```
allEntries = true ensures all cached data under that cache name is cleared.



## Actuator

- Spring Boot Actuator is a built-in Spring Boot module that provides production-ready features to help us to monitor and manage your application.
 It exposes REST end points that give insights into the internal state of our application — such as `health checks , logging , beans , mappings , cache , thread dumps , custom end points, metrics, environment properties and etc`.

- to enable it , add spring boot actuator Dependency

```
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-actuator</artifactId>
</dependency>

```

```
# To enable all endpoints:
management.endpoints.web.exposure.include=*

# If you want actuator endpoints to be served on a different port:
# management.server.port=8081 
 
# Expose only selected actuator endpoints
#management.endpoints.web.exposure.include=health,info,metrics

```
