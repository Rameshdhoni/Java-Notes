package com.spring.project.exception;

public class StudentsNotFoundException extends RuntimeException {
	public StudentsNotFoundException(String message) {
		super(message);
	}
}
