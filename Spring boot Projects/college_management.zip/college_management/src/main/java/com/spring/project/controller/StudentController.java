package com.spring.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.project.entity.Student;

import com.spring.project.service.StudentService;

@RestController
@RequestMapping("/api/students")
public class StudentController {

	/*
	 * Access Swagger documentation JSON API :
	 * http://localhost:8091/CollegeManagement/v3/api-docs Accessing Swagger UI :
	 * http://localhost:8091/CollegeManagement/swagger-ui/index.html
	 */
	@Autowired

	private StudentService studentService;

	@PostMapping
	public Student create(@RequestBody Student student) {
		return studentService.create(student);
	}

	@GetMapping
	public List<Student> getAllStudents() {
		return studentService.getAllStudents();
	}

	@GetMapping("/{id}")
	public Student getStudentById(@PathVariable Long id) {
		return studentService.getStudentById(id);
	}

	@PutMapping("/{id}")
	public Student updateStudent(@PathVariable Long id, @RequestBody Student updatedStudent) {

		return studentService.updateStudent(id, updatedStudent);

	}

	@DeleteMapping("/{id}")
	public String deleteStudent(@PathVariable Long id) {

		return studentService.deleteStudent(id);
	}

	@GetMapping("/search/{name}")
	public List<Student> findByName(@PathVariable String name) {
		return studentService.findByName(name);
	}

}
