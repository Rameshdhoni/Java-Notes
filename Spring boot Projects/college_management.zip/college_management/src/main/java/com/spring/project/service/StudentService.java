package com.spring.project.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.spring.project.entity.Student;
import com.spring.project.exception.StudentNotFoundException;
import com.spring.project.exception.StudentsNotFoundException;
import com.spring.project.repository.StudentRepository;

@Service
public class StudentService {
	@Autowired
	private StudentRepository studentRepository;

	public Student create(Student student) {
		return studentRepository.save(student);
	}

	@Cacheable(value = "students")
	public List<Student> getAllStudents() {
		List<Student> std = studentRepository.findAll();
		if (std.isEmpty()) {
			throw new StudentsNotFoundException("No Students found in the database.");
		}
		return std;
	}

	@Cacheable(value = "studentById", key = "#id")
	public Student getStudentById(Long id) {
		 System.out.println("Fetching from DB for ID: " + id);
		Student std = studentRepository.findById(id)
				.orElseThrow(() -> new StudentNotFoundException("Student with ID " + id + " not found."));
		return std;
	}

	@CachePut(value = "studentById", key = "#id")
	@CacheEvict(value = { "students", "studentByName" }, allEntries = true)
	public Student updateStudent(Long id, Student updatedStudent) {
		Student std = studentRepository.findById(id)
				.orElseThrow(() -> new StudentNotFoundException("Student with ID " + id + " not found."));
		std.setName(updatedStudent.getName());
		std.setAge(updatedStudent.getAge());
		std.setAddress(updatedStudent.getAddress());

		return studentRepository.save(std);

	}

	@CacheEvict(value = { "studentById", "students", "studentByName" }, allEntries = true)
	public String deleteStudent(Long id) {
		Student std = studentRepository.findById(id)
				.orElseThrow(() -> new StudentNotFoundException("Student with ID " + id + " not found."));

		studentRepository.deleteById(std.getId());

		return "Student with ID " + id + " deleted";
	}

	@Cacheable(value = "studentByName", key = "#name")
	public List<Student> findByName(String name) {
		List<Student> std = studentRepository.findByNameContainingIgnoreCase(name);
		if (std.isEmpty()) {
			throw new StudentsNotFoundException("No Students found in the database.");
		}
		return std;
	}
}
