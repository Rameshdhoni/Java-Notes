package com.spring.project;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.spring.project.entity.Student;
import com.spring.project.repository.StudentRepository;
import com.spring.project.service.StudentService;

@SpringBootTest
class CollegeManagementApplicationTests {
	@Autowired
	private StudentService service;
	@MockBean
	private StudentRepository repo;

	@Test
	public void getStudentsTest() {

		when(repo.findAll())
				.thenReturn(Stream.of(new Student(1L, "raju", 12, "hyd"), new Student(2L, "rahul", 21, "hyd"))
						.collect(Collectors.toList()));
		assertEquals(2, service.getAllStudents().size());
	}

	@Test
	public void getStudentByNameTest() {
		String name = "raju";
		when(repo.findByNameContainingIgnoreCase(name))
				.thenReturn(Stream.of(new Student(1L, "raju", 12, "hyd"), new Student(2L, "rahul", 21, "hyd"))
						.collect(Collectors.toList()));
		assertEquals(2, service.findByName(name).size());

	}

	@Test
	public void getStudentByIdTest() {
		Long id = 1L;
		Student student = new Student(id, "raju", 12, "hyd");
		when(repo.findById(id)).thenReturn(Optional.of(student));
		assertEquals("raju", service.getStudentById(id).getName());
	}

	@Test
	public void createStudentTest() {
		Student student = new Student(1L, "raju", 20, "hyd");
		when(repo.save(student)).thenReturn(student);

		assertEquals(student, service.create(student));
	}

	@Test
	public void deleteStudentTest() {
		Long id = 1L;
		Student student = new Student(id, "raju", 20, "hyd");

		when(repo.findById(id)).thenReturn(Optional.of(student));

		String result = service.deleteStudent(id);
		assertEquals("Student with ID 1 deleted", result);
	}

	@Test
	public void updateStudentTest() {
		Long id = 1L;
		Student existingStudent = new Student(id, "raju", 20, "hyd");
		Student updatedStudent = new Student(id, "ravi", 21, "bangalore");

		when(repo.findById(id)).thenReturn(Optional.of(existingStudent));
		when(repo.save(existingStudent)).thenReturn(updatedStudent);

		Student result = service.updateStudent(id, updatedStudent);
		assertEquals("ravi", result.getName());
		assertEquals(21, result.getAge());
		assertEquals("bangalore", result.getAddress());
	}
}
