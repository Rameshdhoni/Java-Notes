# BankingApplication

A Spring Boot based RESTful API project for managing bank accounts. This application allows creating accounts, fetching account details, depositing and withdrawing money, and deleting accounts. It features robust exception handling and logging.

## Project Overview

This project implements a simple banking system backend with basic account operations using Spring Boot and JPA for database interaction. It uses MySQL as the database and supports:

- Account creation  
- Fetching all accounts or by ID  
- Deposit money into account  
- Withdraw money from account with balance check  
- Delete an account  

---

## Technologies Used

- Java 17  
- Spring Boot 3.1.4  
- Spring Data JPA  
- MySQL  
- Lombok (to reduce boilerplate code)  
- Maven (build and dependency management)  
- SLF4J with Logback (logging)  
- Springdoc OpenAPI (Swagger UI for API docs)  

---

## Setup & Configuration

1. **Database**: Create a MySQL database named `banking_app` on localhost (port 3306).  
2. **User credentials**: Update `spring.datasource.username` and `spring.datasource.password` in `application.properties` to your MySQL credentials.  
3. **Port and Context Path**: The server runs on port `8090` with context path `/BankingApplication`.  
4. **Logging**: Application logs are written to `banking-app.log` in the project root.  
5. **Build**: Use Maven to build the project.


### 1. **Entity**

- **`Account`**  
  - Represents the bank account database table (`account_table`).  
  - Fields: `id` (auto-generated primary key), `accountHolderName`, `balance`.  
  - Uses JPA annotations for ORM mapping and Lombok for boilerplate reduction (getters/setters, constructors).  
  - Purpose: Model the account data persisted in the database.

---

### 2. **Repository**

- **`AccountRepository`**  
  - Extends `JpaRepository<Account, Long>`.  
  - Provides built-in CRUD and pagination operations on `Account` entities.  
  - Purpose: Data access layer handling DB operations without custom implementation.

---

### 3. **Service**

- **`AccountService`**  
  - Contains the core business logic for account operations: create, read, deposit, withdraw, delete.  
  - Uses `AccountRepository` for DB interaction.  
  - Validates conditions like account existence and sufficient balance for withdrawals.  
  - Throws custom exceptions when errors occur (account not found, insufficient funds).  
  - Includes logging statements (info and debug levels) to trace method execution and important state changes.  
  - Purpose: Encapsulate business rules and interact with the repository.

---

### 4. **Controller**

- **`AccountController`**  
  - Defines REST endpoints for client interactions.  
  - Maps HTTP requests to service methods, handling JSON request/response bodies.  
  - Endpoints: create account, get all accounts, get by ID, deposit, withdraw, delete.  
  - Handles path variables and request bodies to process transactions.  
  - Purpose: Expose RESTful API endpoints and delegate to service layer.

---

### 5. **Exceptions**

- **`AccountNotFoundException`**  
  - Custom runtime exception thrown when an account with the specified ID does not exist.

- **`InsufficientFundsException`**  
  - Custom runtime exception thrown when withdrawal amount exceeds account balance.

- **`GlobalExceptionHandler`**  
  - Uses `@ControllerAdvice` and `@ExceptionHandler` annotations to intercept exceptions globally.  
  - Returns consistent JSON error responses with HTTP status, error message, and timestamp.  
  - Handles `AccountNotFoundException`, `InsufficientFundsException`, and general `RuntimeException`.  
  - Purpose: Provide centralized error handling and meaningful API error responses.

---

## 6 . **Logging & Logger Configuration**

- Logging is implemented using SLF4J with Logback (default Spring Boot logging framework).  
- Logger is instantiated in `AccountService` via:

  ```java
  private static final Logger logger = LoggerFactory.getLogger(AccountService.class);
  
- Logging in Spring Boot helps record application events and errors, making it easier to debug issues and monitor app health. Logs are stored persistently, so even if the app crashes, you can analyze what happened. Using a logger instead of simple print statements provides better control over log levels, formatting, and output destinations.


## 7 . **Spring Boot Validation **

- This dependency enables declarative Java Bean validation using annotations. It is widely used to validate incoming REST request bodies, form data, and service-level inputs, ensuring that data is clean before business logic is applied.

- Adds support for Java Bean Validation (JSR 380) using Hibernate Validator.

- Use validation annotations like @NotNull, @Size, @Email, etc. on your DTO/model fields.

- In your controller, add @Valid on the request body parameter to trigger validation automatically.

- If validation fails, Spring throws a MethodArgumentNotValidException.

- You can handle this exception globally using @ControllerAdvice to return meaningful error messages to clients.

- To enable validation, the following dependency is included in `pom.xml`:

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-validation</artifactId>
</dependency>```


