package com.spring.project.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.spring.project.entity.Account;
import com.spring.project.service.AccountService;

@WebMvcTest(AccountController.class)
public class AccountControllerTest {
	@MockBean
	private AccountService accountService;
	@Autowired
	MockMvc mockMvc;

	@Autowired
	private ObjectMapper objectMapper;

	@Test
	void createAccount_shouldReturnCreatedAccount() throws Exception {
		Account account = new Account(1L, "Alice", 5000.0);
		when(accountService.create(account)).thenReturn(account);

		mockMvc.perform(post("/api/accounts").contentType(MediaType.APPLICATION_JSON)
				.content(objectMapper.writeValueAsString(account))).andExpect(status().isOk())
				.andExpect(jsonPath("$.accountHolderName").value("Alice"))
				.andExpect(jsonPath("$.balance").value(5000.0));
	}

	@Test
	void getAllAccounts_shouldReturnList() throws Exception {
		List<Account> accounts = List.of(new Account(1L, "John", 1000.0));
		when(accountService.getAccounts()).thenReturn(accounts);

		mockMvc.perform(get("/api/accounts")).andExpect(status().isOk()).andExpect(jsonPath("$.size()").value(1))
				.andExpect(jsonPath("$[0].accountHolderName").value("John"));
	}
}
