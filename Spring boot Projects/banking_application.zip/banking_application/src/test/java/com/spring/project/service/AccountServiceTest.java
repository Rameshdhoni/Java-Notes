package com.spring.project.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.spring.project.entity.Account;
import com.spring.project.exception.AccountsNotFoundException;
import com.spring.project.repository.AccountRepository;

@ExtendWith(MockitoExtension.class)
public class AccountServiceTest {

	@Mock
	private AccountRepository accountRepository;

	@InjectMocks
	private AccountService accountService;

	@Test
	void createAccountShouldReturnSavedAccount() {
		// 1. Data Preparation
		Account account = new Account(1L, "Ramesh", 5000.00);

		// 2. Mocking
		when(accountRepository.save(account)).thenReturn(account);

		// 3. Call actual method
		Account createdAccount = accountService.create(account);

		// 4. Assertions
		assertNotNull(createdAccount);
		assertEquals(account.getAccountHolderName(), createdAccount.getAccountHolderName());
		assertEquals(5000.00, createdAccount.getBalance());
	}

	@Test
	void getAccountsShouldReturnList() {
		Account a1 = new Account(1L, "Ramesh", 5000.0);
		Account a2 = new Account(2L, "Suresh", 7000.0);
		when(accountRepository.findAll()).thenReturn(Arrays.asList(a1, a2));

		List<Account> result = accountService.getAccounts();
		assertEquals(2, result.size());
	}

	@Test
	void getAccountsShouldThrowExceptionWhenEmpty() {
		when(accountRepository.findAll()).thenReturn(Collections.emptyList());

		assertThrows(AccountsNotFoundException.class, () -> accountService.getAccounts());
	}

	@Test
	void getAccountShouldReturnAccount() {
		Account account = new Account(1L, "Ramesh", 5000.0);
		when(accountRepository.findById(1L)).thenReturn(Optional.of(account));

		Optional<Account> result = accountService.getAccount(1L);
		assertTrue(result.isPresent());
		assertEquals("Ramesh", result.get().getAccountHolderName());
	}
}
