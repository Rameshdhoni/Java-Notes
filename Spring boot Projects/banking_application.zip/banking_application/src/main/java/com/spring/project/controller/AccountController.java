package com.spring.project.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.project.dto.AmountRequest;
import com.spring.project.entity.Account;
import com.spring.project.exception.AccountNotFoundException;
import com.spring.project.service.AccountService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/accounts")
public class AccountController {
	/*
	 * Access Swagger documentation JSON API :
	 * http://localhost:8090/BankingApplication/v3/api-docs Accessing Swagger UI :
	 * http://localhost:8090/BankingApplication/swagger-ui/index.html
	 */
	@Autowired
	private AccountService accountService;

	@PostMapping
	public Account create(@Valid @RequestBody Account account) {
		return accountService.create(account);
	}

	@GetMapping
	public List<Account> getAccounts() {
		return accountService.getAccounts();
	}

	@GetMapping("/{accountNumber}")
	public Account getAccount(@PathVariable Long accountNumber) {
		return accountService.getAccount(accountNumber).orElseThrow(
				() -> new AccountNotFoundException("Account not found with accountNumber " + accountNumber));
	}

	@PostMapping("/{accountNumber}/deposit")
	//public Account depoAccount(@PathVariable Long accountNumber, @RequestBody Map<String, Double> request) {
	public Account depoAccount(@PathVariable Long accountNumber, @Valid @RequestBody AmountRequest request) {
		//Double amount = request.get("amount");
		return accountService.deposit(accountNumber, request.getAmount());
	}

	@PostMapping("/{accountNumber}/withdraw")
	//public Account withdraw(@PathVariable Long accountNumber, @RequestBody Map<String, Double> request) {
	public Account withdraw(@PathVariable Long accountNumber, @Valid @RequestBody AmountRequest request) {
		//Double amount = request.get("amount");
		return accountService.withdraw(accountNumber, request.getAmount());
	}

	@DeleteMapping("/{accountNumber}")
	public String deleteAccount(@PathVariable Long accountNumber) {
		return accountService.deleteAccount(accountNumber);
	}
}
