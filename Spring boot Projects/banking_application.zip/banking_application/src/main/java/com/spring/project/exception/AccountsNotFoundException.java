package com.spring.project.exception;

public class AccountsNotFoundException extends RuntimeException{
	
	public AccountsNotFoundException(String message) {
		super(message);
    }

}

