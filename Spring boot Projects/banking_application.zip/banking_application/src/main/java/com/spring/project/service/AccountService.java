package com.spring.project.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.project.entity.Account;
import com.spring.project.exception.AccountNotFoundException;
import com.spring.project.exception.AccountsNotFoundException;
import com.spring.project.exception.InsufficientFundsException;
import com.spring.project.repository.AccountRepository;

@Service
public class AccountService {

	private static final Logger logger = LoggerFactory.getLogger(AccountService.class);

	@Autowired
	private AccountRepository accountRepository;

	public Account create(Account account) {
		logger.info("Creating account for: {}", account.getAccountHolderName());
		return accountRepository.save(account);
	}

	public List<Account> getAccounts() {
	    logger.debug("Fetching all accounts");
	    List<Account> accounts = accountRepository.findAll();
	    if (accounts.isEmpty()) {
	        throw new AccountsNotFoundException("No accounts found in the database.");
	    }
	    return accounts;
	}

	public Optional<Account> getAccount(Long accountNumber) {
		logger.debug("Fetching account with accountNumber : {}", accountNumber);
		return accountRepository.findById(accountNumber);
	}

	public Account deposit(Long accountNumber, double amount) {
		logger.info("Depositing amount: {} to account accountNumber : {}", amount, accountNumber);
		Account account = accountRepository.findById(accountNumber)
				.orElseThrow(() -> new AccountNotFoundException("Account not found with accountNumber " + accountNumber));
		account.setBalance(account.getBalance() + amount);
		return accountRepository.save(account);
	}

	public Account withdraw(Long accountNumber, double amount) {
		logger.info("Attempting withdrawal of amount: {} from account accountNumber : {}", amount, accountNumber);
		Account account = accountRepository.findById(accountNumber)
				.orElseThrow(() -> new AccountNotFoundException("Account not found with accountNumber " + accountNumber));
		if (account.getBalance() < amount) {
			throw new InsufficientFundsException("Insufficient funds");
		}

		account.setBalance(account.getBalance() - amount);
		return accountRepository.save(account);
	}

	public String deleteAccount(Long accountNumber) {
		logger.info("Deleting account with accountNumber : {}", accountNumber);
		if (!accountRepository.findById(accountNumber).isPresent()) {
			throw new AccountNotFoundException("Account not found with accountNumber " + accountNumber);
		}
		/*
		 * or using accountRepository.findById(accountNumber) .orElseThrow(() -> new
		 * AccountNotFoundException("Account not found with accountNumber " + accountNumber));
		 */
		accountRepository.deleteById(accountNumber);
		return "Account deleted successfully with accountNumber " + accountNumber;
	}

}
